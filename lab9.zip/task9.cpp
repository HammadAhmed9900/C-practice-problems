#include<iostream>
using namespace std;

int main() {
	int arr[5] = { 10,20,30,40,50 };
	int n;
	cin>>n;
	bool found=false;
		for(int i=0;i<5;i++){
		if (arr[i] == n) {
		found=true;
		}
		}
		cout << "vnumber to check "<<n<<endl;
		if(found){
		cout<<n<< " is found in array"<<endl;
	}
	else{
	cout<<n<<" not found in array";
	}
	return 0;
}