#include<iostream>
using namespace std;

int main() {
	int count1 = 0;
	int count2 = 0;
	int arr[5] = { 1,2,3,4,5 };
	for (int i = 0; i < 5; i++) {
		if (arr[i] % 2 == 0) {
			count1++;
		}
		if (arr[i] % 2 != 0) {
			count2++;
		}
	}

	cout << "even " << count1 << endl << "odd " << count2;
	return 0;
}