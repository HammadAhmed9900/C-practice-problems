#include<iostream>
using namespace std;

int main() {

	int arr[5] = { 3,8,1,6,2 };
	int small=arr[0];
	int large=arr[0];
	for (int i = 1; i <5; i++) {
		if (small < arr[i]) {
		small=arr[i];
			cout<<arr[i]<<endl;
	}
		if (large > arr[i]) {
		large=arr[i];
		 cout<<arr[i]<<endl;
	}
	}
	return 0;
}